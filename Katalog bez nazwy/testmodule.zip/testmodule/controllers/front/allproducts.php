<?php
Class testmoduleAllproductsModuleFrontController extends ModuleFrontController
{
 	public function init()
	{
    	$this->page_name = 'allproducts'; // page_name and body id
		//$this->display_column_left = false;
		//$this->display_column_right = false;
    	parent::init();
	}

	public function setMedia()
	{
    	parent::setMedia();
    	$this->addCSS(__PS_BASE_URI__.'modules/'.$this->module->name.'/css/'.$this->module->name.'.css');
    	 
	}

	public function initContent()
	{
	    parent::initContent();
 
	    //$products_count = $this->module->countAllProducts();
	    //$this->pagination($products_count); // needs to be here, so that page number and products per page are assigned to "p" and "n"
	     
		
	    //$products_partial = Product::getProducts($this->context->language->id, ((int)$this->p - 1) * (int)$this->n, $this->n, 'name', 'asc');
		//$products = Product::getProductsProperties($this->context->language->id, $products_partial);
		//print_r($products_partial);		
	
		$cookie = $_COOKIE["mojcookie"];
		$command = 'jdk1.8.0_151/bin/java -jar recommender-1.0-SNAPSHOT-jar-with-dependencies.jar '.$cookie;

		$output = shell_exec($command);

		$productIDs = split(",",$output);
		$products_partial = array();
	
		foreach($productIDs as $productID)
		{
		
			foreach(Product::getProducts($this->context->language->id,$productID-1,50,'id_shop_default','ASC') as $something)
			{
				//print_r($something);
				if($something[id_product] == $productID)
				{
					array_push($products_partial,$something);
					break;
				}
			}

			foreach(Product::getProducts($this->context->language->id,$productID-50,50,'id_shop_default','ASC') as $something)
			{
				//print_r($something);
				if($something[id_product] == $productID)
				{
					array_push($products_partial,$something);
					break;
				}
			}
		}		
		//print_r($products_partial);		
		$products = Product::getProductsProperties($this->context->language->id, $products_partial); 		

    	$this->context->smarty->assign(array(
        	'products' => $products,
        	'homeSize' => Image::getSize('home_default')
    	));
	
		foreach ($products as $key => $product) {
		    foreach ($products as $key => $product) {
		        $products[$key]['id_image'] = Product::getCover($product['id_product']).['id_image'];
		    }
		}
	
	    $this->setTemplate('allproducts.tpl');
	} 

	public function countAllProducts()
	{
    	return Db::getInstance()->getValue('SELECT COUNT(*) from ps_product WHERE active = 1');
	}

	public function getImageLink($name, $ids, $type = null)
   	{
		return ($this->allow == 1) ? (__PS_BASE_URI__.$ids.($type ? '-'.$type : '').'/'.$name.'.jpg') : (_THEME_PROD_DIR_.$ids.($type ? '-'.$type : '').'.jpg');
   	}
}


