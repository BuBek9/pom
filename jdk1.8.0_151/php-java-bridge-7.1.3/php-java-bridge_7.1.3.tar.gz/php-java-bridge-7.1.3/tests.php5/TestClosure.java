public interface TestClosure {
    public Object f();
}
