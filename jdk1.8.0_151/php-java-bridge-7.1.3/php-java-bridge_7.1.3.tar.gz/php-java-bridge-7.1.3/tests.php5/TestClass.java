public class TestClass {
    public String getName() {
	return "test clazz";
    }
}