import java.util.*;

public class TestArrayMapCollection {
    public TestArrayMapCollection[] array(TestArrayMapCollection[] x) {
	return x;
    }
    public Map map(Map m) {
	return m;
    }
    public List list(List m) {
	return m;
    }
    public Collection collection(Collection m) {
	return m;
    }
}
