public class HashSetFactory {
    public static java.util.HashSet getSet() {
	return new java.util.HashSet();
    }
}
