<?php

show_source(basename($_GET["source"]));

?>
