package php.java.test.php5;

public interface TestClosure {
    public Object f();
}
