package php.java.test.php5;

public interface TestClosure1 {
    public Object g();
}
